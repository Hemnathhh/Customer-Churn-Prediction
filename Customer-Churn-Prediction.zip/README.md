# Customer Churn Prediction

## Objective
Predict customer churn using Telco customer data.

## Dataset
- Source: Kaggle - https://www.kaggle.com/datasets/blastchar/telco-customer-churn

## Tools Used
- Python, Pandas, NumPy, Scikit-learn, Seaborn, Matplotlib

## Models
- Logistic Regression
- Random Forest

## Steps
1. Data Cleaning & Preprocessing
2. Encoding Categorical Features
3. Model Training
4. Evaluation using Classification Report and Confusion Matrix

## Output
- Binary churn prediction
- Model evaluation metrics
